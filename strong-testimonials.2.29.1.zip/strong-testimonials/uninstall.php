<?php
/**
 * Strong Testimonials uninstall procedure
 */
 
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit();

// TODO Leave No Trace
