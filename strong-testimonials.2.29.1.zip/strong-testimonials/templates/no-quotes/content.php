<?php
/**
 * Template Name: Default with No Quotes
 * Description: A version of the default template without the quote symbol in the heading.
 */
?>
<?php include WPMTST_DEF_TPL . 'content.php'; ?>
