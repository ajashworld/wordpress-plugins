<?php
/**
 * Template Name: Default with Image on Right
 * Description: A version of the default template with the image on the right and client fields on the left.
 */
?>
<?php include WPMTST_DEF_TPL . 'content.php'; ?>
