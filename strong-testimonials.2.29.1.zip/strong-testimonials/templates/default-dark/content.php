<?php
/**
 * Template Name: Default Dark
 * Description: A version of the default template for dark themes.
 */
?>
<?php include WPMTST_DEF_TPL . 'content.php'; ?>