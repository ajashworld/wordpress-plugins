<div class="then <?php echo apply_filters( 'wpmtst_view_section', '', 'compat' ); ?>" style="display: none;">
	<h3>
		<?php _e( 'Compatibility', 'strong-testimonials' ); ?>
	</h3>
	<table class="form-table multiple group-general">
		<tr class="then then_display then_form then_slideshow then_not_single_template" style="display: none;">
			<?php include( 'option-divi.php' ); ?>
		</tr>
	</table>
</div>
