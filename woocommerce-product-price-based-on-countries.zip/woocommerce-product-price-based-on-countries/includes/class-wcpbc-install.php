<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * WCPBC_Install Class
 *
 * Installation related functions and actions.
 *
 * @author 		oscargare 
 * @version     1.7.0
 */

class WCPBC_Install {
	
	/**
	 * Hooks.
	 */
	public static function init() {				
		add_action( 'admin_init', array( __CLASS__, 'update_actions' ), 5 );
		add_action( 'admin_init', array( __CLASS__, 'check_version' ) );				
	}

	/**
	 * Get install version
	 */
	private static function get_install_version() {

		$install_version = get_option( 'wc_price_based_country_version', null );

		if ( is_null( $install_version ) && get_option('_oga_wppbc_countries_groups') ) {
			$install_version = '1.3.1';
		}

		return $install_version;
	}	
	
	/**
	 * Update WCPBC version
	 */
	private static function update_wcpbc_version() {				
		update_option( 'wc_price_based_country_version', WCPBC()->version );				
	}
	
	/**
	 * Sync product prices 
	 */
	public static function sync_exchange_rate_prices(){
		$zones = get_option( 'wc_price_based_country_regions', array() );
		foreach ( $zones as $zone_id => $zone ) {
			wcpbc_sync_exchange_rate_prices( $zone_id, $zone['exchange_rate'] );
		}
	}
	
	/**
	 * Install function 
	 */ 
	public static function install(){
		
		$current_version = self::get_install_version();
		
		if ( null !== $current_version && version_compare( $current_version, '1.6.2', '<' ) ) {
			WCPBC_Admin_Notices::add_notice( 'update_db' );
		} else {
			// Update version
			self::update_wcpbc_version();
			
			// Sync exchange rate prices
			self::sync_exchange_rate_prices();			
		}				
	}

	/**
	 * check_version function.
	 */
	public static function check_version() {
				
		if (  ! defined( 'IFRAME_REQUEST' ) && version_compare( self::get_install_version(), '1.6.2', '<' ) ) {
			WCPBC_Admin_Notices::add_notice( 'update_db' );
		} else {
			// Update version
			self::update_wcpbc_version();
		}
	}

	/**
	 * Handle updates
	 */
	public static function update_actions() {

		if ( ! empty( $_GET['do_update_wc_price_based_country'] ) ) {

			$install_version = self::get_install_version();
			$db_updates         = array(
				'1.3.2' => 'updates/wcpbc-update-1.3.2.php',
				'1.4.0' => 'updates/wcpbc-update-1.4.0.php',
				'1.5.0' => 'updates/wcpbc-update-1.5.0.php',
				'1.6.0' => 'updates/wcpbc-update-1.6.0.php',
				'1.6.2' => 'updates/wcpbc-update-1.6.2.php'				
			);

			foreach ( $db_updates as $version => $updater ) {
				if ( version_compare( $install_version, $version, '<' ) ) {					
					include( $updater );				
				}
			}

			self::update_wcpbc_version();	
			WCPBC_Admin_Notices::remove_notice( 'update_db' );	
		}		
	}		
}

WCPBC_Install::init();