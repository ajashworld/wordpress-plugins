<?php
/**
Component Name: OTW Factory
Plugin URI: http://OTWthemes.com
Description:  OTW Form
Author: OTWthemes.com
Version: 1.1
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Factory';
$otw_component['version']    = '0000.3';
$otw_component['class_name'] = 'OTW_Factory';
?>