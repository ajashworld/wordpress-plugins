<?php
/**
Component Name: OTW Post Template Shortcode
Plugin URI: http://OTWthemes.com
Description:  OTW Post Template Shortcode
Author: OTWthemes.com
Version: 1.2
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Post Template Shortcode';
$otw_component['version']    = '3000.1';
$otw_component['class_name'] = 'OTW_Post_Template_Shortcode';

?>