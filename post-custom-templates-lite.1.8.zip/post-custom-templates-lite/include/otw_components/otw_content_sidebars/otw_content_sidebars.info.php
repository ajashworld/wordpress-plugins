<?php
/**
Component Name: OTW Content Sidebars
Plugin URI: http://OTWthemes.com
Description:  OTW Content Sidebars
Author: OTWthemes.com
Version: 5.1
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Content Sidebars';
$otw_component['version']    = '5000.1';
$otw_component['class_name'] = 'OTW_Content_Sidebars';

?>