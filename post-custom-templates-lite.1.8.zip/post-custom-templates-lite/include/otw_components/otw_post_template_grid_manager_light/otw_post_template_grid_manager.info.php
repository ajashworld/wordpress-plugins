<?php
/**
Component Name: OTW Post Template Grid Manager Light
Plugin URI: http://OTWthemes.com
Description:  OTW Grid Manager
Author: OTWthemes.com
Version: 0.001 light version
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Post Template Grid Manager';
$otw_component['version']    = '0.002';
$otw_component['class_name'] = 'OTW_Post_Template_Grid_Manager';

?>