<?php
$otw_pctl_content_sidebars_object->labels['Select default or custom settings']=__('Select default or custom settings', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Default means that you want to apply the default settings for the OTW Content sidebars set in the left WP menu. Custom measns the settings will apply form what you set bellow.']=__('Default means that you want to apply the default settings for the OTW Content sidebars set in the left WP menu. Custom measns the settings will apply form what you set bellow.', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Sidebars Configuration']=__('OTW Sidebars Configuration', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Choose sidebar configuration.']=__('Choose sidebar configuration.', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Primary Sidebar']=__('OTW Primary Sidebar', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Choose what sidebar should be displayed as OTW Primary sidebar.']=__('Choose what sidebar should be displayed as OTW Primary sidebar.', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Secondary Sidebar']=__('OTW Secondary Sidebar', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Primary Sidebar Width']=__('OTW Primary Sidebar Width', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Choose the width for your Primary sidebar in columns. The whole content area including sidebars is 24 columns.']=__('Choose the width for your Primary sidebar in columns. The whole content area including sidebars is 24 columns.', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Secondary Sidebar Width']=__('OTW Secondary Sidebar Width', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Choose the width for your Secondary sidebar in columns. The whole content area including sidebars is 24 columns.']=__('Choose the width for your Secondary sidebar in columns. The whole content area including sidebars is 24 columns.', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Content Sidebars']=__('OTW Content Sidebars', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['OTW Content Sidebars are positions that you can set and use to add sidebars to your pages/posts. Bellow you set the defaults for you post and pages. If you want a different configuration for a certain page or post you can override defaults from the OTW Content Sidebar metabox when you edit that page or post.']=__('OTW Content Sidebars are positions that you can set and use to add sidebars to your pages/posts. Bellow you set the defaults for you post and pages. If you want a different configuration for a certain page or post you can override defaults from the OTW Content Sidebar metabox when you edit that page or post.', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['default settings for OTW Content Sidebars']=__('default settings for OTW Content Sidebars', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Save Default Settings']=__('Save Default Settings', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Pages']=__('Pages', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Posts']=__('Posts', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['none']=__('none', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['default']=__('default', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Default settings saved!']=__('Default settings saved!', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Default']=__('Default', 'otw_pctl');
$otw_pctl_content_sidebars_object->labels['Custom']=__('Custom', 'otw_pctl');
?>