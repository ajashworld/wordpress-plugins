<?php
$otw_pctl_factory_object->labels['License Details']=__('License Details', 'otw_pctl');
$otw_pctl_factory_object->labels['Domain']=__('Domain', 'otw_pctl');
$otw_pctl_factory_object->labels['Version']=__('Version', 'otw_pctl');
$otw_pctl_factory_object->labels['No information available']=__('No information available', 'otw_pctl');
$otw_pctl_factory_object->labels['Expires']=__('Expires', 'otw_pctl');
$otw_pctl_factory_object->labels['Product Code']=__('Product Code', 'otw_pctl');
$otw_pctl_factory_object->labels['Please confirm to deregister the code?']=__('Please confirm to deregister the code?', 'otw_pctl');
$otw_pctl_factory_object->labels['Delete Code']=__('Delete Code', 'otw_pctl');
$otw_pctl_factory_object->labels['Have a code, paste it here']=__('Have a code, paste it here', 'otw_pctl');
$otw_pctl_factory_object->labels['Submit Code']=__('Submit Code', 'otw_pctl');
$otw_pctl_factory_object->labels['No plugin information found.']=__('No plugin information found.', 'otw_pctl');
?>