<!-- Blog Title -->
<div class="otw_post_content-blog-title-wrapper otw_post_content-format-image">
	<h1 class="otw_post_content-blog-title"><?php echo $post->post_title;?></h1>
</div>
<!-- End Blog Title -->